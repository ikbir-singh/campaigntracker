const express = require("express");
const router = express.Router();

// const jwt = require("jsonwebtoken");

const authenticate = require('../middleware/authenticate');

const project = require("../models/projectSchema");
const reel = require("../models/reelSchema");
const cron = require("../models/cronSchema");
const page = require("../models/pageSchema");
const pagebatch = require("../models/pagebatchSchema");
// const tournaments = require("../models/tournamentSchema");
// const countries = require("../models/countriesSchema");
// const tournament_fee_reward = require("../models/tournamentsFeeRewardSchema");
// const tournament_banners = require("../models/tournamentBannersSchema");
// const quick_tournaments = require("../models/quicktournamentsSchema");
// const manage_Spin_Wheel = require("../models/manageSpinWheelSchema");
// const manageRedemption = require("../models/redemptionShema");
// const portal_settings = require("../models/portalSchema");
const userLogin = require("../models/loginSchema");

// const multer = require('multer')

const bcrypt = require("bcryptjs");

const http = require("https");
const { Console } = require("console");


// const storage = multer.diskStorage({
//     destination: (req, file, cb) => {
//         // cb(null, '../admin/public/uploads/practise-banners')
//     },
//     filename: (req, file, cb) => {
//         cb(null, new Date().getTime()+'_'+file.originalname)
//     },
// });
// const upload = multer({ storage: storage })


// for single file upload function
// var uploadFnct = function (dest, file) {
//     var storage = multer.diskStorage({ //multers disk storage settings
//         destination: function (req, file, cb) {
//             cb(null, '../admin/public/uploads/' + dest + '/');
//         },
//         filename: function (req, file, cb) {
//             // var datetimestamp = Date.now();
//             cb(null, new Date().getTime() + '_' + file.originalname);
//         }
//     });

//     var upload = multer({ //multer settings
//         storage: storage
//     }).single(file);

//     return upload;
// };

// for bcrypt password 
const bcrypt_function = async (password) => {
    let bcrypt_pass = await bcrypt.hash(password, 10);
    // console.log("bcrypt_pass: "+bcrypt_pass);
    return bcrypt_pass;
}

router.get("/", (req, res) => {
    console.log("connect");
});



// testing
router.get("/testing", async (req, res) => {
    try {

        const fs = require('fs');
        const String = "\n" + Date();
        fs.appendFile("./foo.txt", String, 'utf8', function (err) {
            if (err) {
                res.status(422).json(err);
            }
            else {
                res.status(201).json("Success");
            }
        });
    }
    catch (error) {
        res.status(422).json(error);

    }
});





//login route
router.post('/login', async (req, res) => {

    try {

        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(404).json({ error: "please fill the data" })
        }
        else {
            const user = await userLogin.findOne({ username: username });
            // console.log(user);
            if (user) {

                let user_pass = user['password'];

                let compare_password = await bcrypt.compare(password, user_pass);
                // console.log("compare_password: " + compare_password);

                if (compare_password === true) {

                    let user_status = user['user_status'];

                    if (user_status === "1") {

                        const token = await user.generateAuthToken();

                        res.cookie("usertoken", token, {
                            expires: new Date(Date.now() + 28800000), //time in milliseconds means 28800000 is 8 hours 
                            httpOnly: true
                        });
                        // console.log(cookie);
                        res.status(201).json({ message: "User Signin Successfully" });
                    }

                    else {
                        res.status(404).json({ message: "Invaild Permission! Contact to Admin" });

                    }


                }

                else {
                    res.status(404).json({ message: "Incorrect Password!" });

                }
            }
            else {
                res.status(404).json({ message: "Username Not Exist, Contact to Admin" });
            }
        }
    }

    catch (err) {
        console.log(err);

    }
});

//  logout route
router.get("/logout", async (req, res) => {
    res.clearCookie('usertoken', { path: '/' })
    res.status(201).send("Logout Successfully");
})


//get token
router.get("/gettoken", authenticate, async (req, res) => {

    let data = {};
    try {
        const userId = req.userId;
        const usertype = req.usertype;
        const user = await userLogin.findOne({ user_id: userId });
        let user_status = user['user_status'];

        if (user_status === "1") {
            data = {
                usertype: usertype,
                userId: userId
            }
            res.status(201).send(data);
        }

        else {
            res.status(404).json({ message: "Invaild Permission! Contact to Admin" });

        }

    }
    catch (error) {
        res.status(422).send(error);

    }
});

// get login details
router.get("/getLoginData/:id", async (req, res) => {
    try {

        const { id } = req.params;
        // console.log(id);

        const userData = await userLogin.findOne({ user_id: id });
        res.status(201).json(userData);

    }
    catch (error) {
        res.status(422).json(error);

    }
});





//get user list for admin
router.post("/getUser", async (req, res) => {
    const { value } = req.body;
    try {

        if (value) {
            const userdata = await userLogin.find({ user_type: "1", $or: [{ name: { $regex: value, $options: "i" } }, { username: { $regex: value, $options: "i" } }] });
            // console.log(userdata);
            if (userdata) {
                res.status(201).json(userdata);
            }
            else {
                const userdata = await userLogin.find({ user_type: "1" });
                // console.log(userdata);
                res.status(201).json(userdata);
            }
        }
        else {
            const userdata = await userLogin.find({ user_type: "1" });
            // console.log(userdata);
            res.status(201).json(userdata);
        }
    }
    catch (error) {
        res.status(422).json(error);

    }

});


//get Active user list for admin
router.post("/getActiveUser", async (req, res) => {
    try {
        const userdata = await userLogin.find({ user_type: "1", user_status: "1" }, { name: 1, _id: 0, user_id: 1 });
        // console.log(userdata);
        res.status(201).json(userdata);
    }
    catch (error) {
        res.status(422).json(error);

    }

});


// add project 
router.post("/addUser", async (req, res) => {

    const userdatacount = (await userLogin.findOne({ user_type: "1" }).sort({ _id: -1 }).limit(1));

    const user_id = (userdatacount != null) ? parseInt(userdatacount["user_id"]) + 1 : "1";  //user id auto imcrement

    const { name, email, encryptPass } = req.body;   // getting data from user

    if (!user_id || !name || !email || !encryptPass) {
        res.status(404).json("please fill the data");
    }
    else {
        try {

            let username = email
            let user_status = 1
            let user_type = 1

            const preuser = await userLogin.findOne({ email: email });
            // console.log(preuser);

            if (preuser) {
                res.status(404).json("This email is already present");
            }
            else {

                let password = await bcrypt_function(encryptPass);
                const adduser = new userLogin({
                    user_id, name, email, password, user_type, user_status, username
                });

                await adduser.save();
                res.status(201).json(adduser);
                // console.log(adduser);
            }

        }
        catch (error) {
            res.status(404).json(error)
        }
    }

});


//get individual project detail
router.get("/getUser/:id", async (req, res) => {
    try {
        const { id } = req.params;
        // console.log(id);

        const user_info = await userLogin.findOne({ user_id: id });
        // console.log(user_info);
        res.status(201).json(user_info)
    }
    catch (error) {
        res.status(422).json(error)
    }
});



//update project
router.patch("/updateUser/:id", async (req, res) => {

    const { id } = req.params;
    var { name, email, status, password } = req.body;

    if (!id || !name || !email || !status) {
        res.status(422).json("please fill the data");
    }
    else {
        try {
            let username = email
            if (password) {
                let bcrypt_password = await bcrypt_function(password);
                const user_update = await userLogin.findByIdAndUpdate(id, { $set: { name: name, email: email, username: username, user_status: status, password: bcrypt_password } }, {
                    new: true
                });

                // console.log(user_update);
                res.status(201).json(user_update)
            }
            else {
                const user_update = await userLogin.findByIdAndUpdate(id, { $set: { name: name, email: email, username: username, user_status: status } }, {
                    new: true
                });

                // console.log(user_update);
                res.status(201).json(user_update)
            }

        }
        catch (error) {
            res.status(422).json(error);
        }
    }

});


//delete user
router.delete("/deleteUser/:id", async (req, res) => {
    try {
        // console.log(req.params);
        const { id } = req.params;

        const user_delete = await userLogin.findByIdAndDelete({ _id: id });

        // console.log(user_delete);
        res.status(201).json(user_delete)
    }
    catch (error) {
        res.status(422).json(error);
    }
});


// update password api

router.patch("/updatePassword/:id", async (req, res) => {
    try {

        const { id } = req.params;

        var { OldPassword, NewPassword, ConfirmPassword } = req.body;

        if (id && OldPassword && NewPassword && ConfirmPassword) {

            if (NewPassword !== ConfirmPassword) {
                res.status(422).json("Confirm Password should be as New Password.");
            }
            else {
                const check_user = await userLogin.find({ user_id: id });
                // console.log(check_user);

                if (check_user[0]) {

                    let _id = check_user[0]['_id'];
                    let old_pass = check_user[0]['password'];

                    let compare_password = await bcrypt.compare(OldPassword, old_pass);

                    if (compare_password === true) {

                        let bcrypt_password = await bcrypt_function(ConfirmPassword);
                        const password_update = await userLogin.findByIdAndUpdate(_id, { $set: { password: bcrypt_password } }, {
                            new: true
                        });

                        // console.log(password_update);
                        res.status(201).json(password_update)
                    }
                    else {
                        res.status(422).json("Old Password is not Same");
                    }
                }

                else {
                    res.status(422).json("user not exists.");
                }
            }

        }
        else {
            res.status(422).json("please fill the data");
        }



    }
    catch (error) {
        res.status(422).json(error);
    }

});


//get projectlist for header
router.post("/getHeaderProjectList", async (req, res) => {
    const { user_id, UserType } = req.body;
    try {
        if (UserType === '-1') {
            const projectdata = await project.find({ project_status: "1" });
            // console.log(projectdata);
            res.status(201).json(projectdata);
        }
        else if (user_id) {
            const projectdata = await project.find({ project_status: "1", project_users: user_id });
            // console.log(projectdata);
            res.status(201).json(projectdata);
        }
        else {
            res.status(422).json("please fill the data");
        }
    }
    catch (error) {
        res.status(422).json(error);

    }

});

//get projectlist
router.post("/getProject", async (req, res) => {
    const { user_id, value } = req.body;
    try {
        if (user_id) {
            if (value) {
                const projectdata = await project.find({ project_users: user_id, project_name: { $regex: value, $options: "i" } });
                // console.log(projectdata);
                if (projectdata) {
                    res.status(201).json(projectdata);
                }
                else {
                    const projectdata = await project.find({ project_users: user_id });
                    // console.log(projectdata);
                    res.status(201).json(projectdata);
                }
            }
            else {
                const projectdata = await project.find({ project_users: user_id });
                // console.log(projectdata);
                res.status(201).json(projectdata);
            }

        }

        else {
            if (value) {
                const projectdata = await project.find({ project_name: { $regex: value, $options: "i" } });
                // console.log(projectdata);
                if (projectdata) {
                    res.status(201).json(projectdata);
                }
                else {
                    const projectdata = await project.find();
                    // console.log(projectdata);
                    res.status(201).json(projectdata);
                }
            }
            else {
                const projectdata = await project.find();
                // console.log(projectdata);
                res.status(201).json(projectdata);
            }
        }

    }
    catch (error) {
        res.status(422).json(error);

    }

});


// add project 
router.post("/addProject", async (req, res) => {

    const projectdatacount = (await project.findOne().sort({ _id: -1 }).limit(1));

    const project_id = (projectdatacount != null) ? parseInt(projectdatacount["project_id"]) + 1 : "1";  //project id auto imcrement

    const project_added_on = Date();  // added on date

    const project_updated_on = Date();   // added on date

    const { user_id, projectName, startDate, selectedusers } = req.body;   // getting data from user

    // console.log(selectedusers);

    let project_name = projectName
    let project_starts_on = startDate
    let d = new Date(startDate);
    let date = (d.getFullYear() + 1) + '-' + (d.getMonth() + 1) + '-' + ((d.getDate() < 10) ? '0' + d.getDate() : d.getDate())
    let project_ends_on = date
    let project_status = 1
    let project_users = selectedusers;

    if (!user_id || !project_name || !project_starts_on || !project_ends_on || !project_status) {
        res.status(404).json("please fill the data");
    }
    else {
        try {
            const preproject = await project.findOne({ project_name: project_name });
            // console.log(preproject);

            if (preproject) {
                res.status(404).json("This project name is already present");
            }
            else {
                const addproject = new project({
                    user_id, project_id, project_name, project_status, project_users, project_starts_on, project_ends_on, project_added_on, project_updated_on
                });

                await addproject.save();
                res.status(201).json(addproject);
                // console.log(addproject);
            }

        }
        catch (error) {
            res.status(404).json(error)
        }
    }



});


//get individual project detail
router.get("/getProject/:id", async (req, res) => {
    try {
        const { id } = req.params;
        // console.log(id);

        const project_info = await project.findOne({ project_id: id });
        // console.log(project_info);
        res.status(201).json(project_info)
    }
    catch (error) {
        res.status(422).json(error)
    }
});



//update project
router.patch("/updateProject/:id", async (req, res) => {

    const { id } = req.params;
    var { projectStatus, startDate, project_updated_on, selectedusers } = req.body;

    if (!id || !projectStatus || !startDate || !project_updated_on) {
        res.status(422).json("please fill the data");
    }
    else {
        try {
            // console.log(req.params);
            let project_users = selectedusers;

            const project_update = await project.findByIdAndUpdate(id, { $set: { project_status: projectStatus, project_starts_on: startDate, project_updated_on: project_updated_on, project_users: project_users } }, {
                new: true
            });

            // console.log(project_update);
            res.status(201).json(project_update)
        }
        catch (error) {
            res.status(422).json(error);
        }
    }

});


//delete project
router.delete("/deleteProject/:id", async (req, res) => {
    try {
        // console.log(req.params);
        const { id } = req.params;

        const project_delete = await project.findByIdAndDelete({ _id: id });

        // console.log(project_delete);
        res.status(201).json(project_delete)
    }
    catch (error) {
        res.status(422).json(error);
    }
});


//get reellist
router.get("/getReel/:project_id", async (req, res) => {
    try {
        const { project_id } = req.params;
        // console.log(id);
        const reeldata = await reel.find({ project_id: project_id, reel_is_traverse: '1' }).sort({ reel_updated_at: -1 });
        res.status(201).json(reeldata);
        // console.log(reeldata);
    }
    catch (error) {
        res.status(422).json(error);

    }
});


//get reellist where
router.post("/getReel", async (req, res) => {
    const { project_id, start_date, end_date } = req.body;
    // console.log("project_id: "+project_id)
    // console.log("start_date: "+start_date)
    // console.log("end_date: "+end_date)

    try {
        if (!project_id) {
            res.status(404).json("please fill the data");
        }
        else {

            if (end_date && start_date) {
                const reeldata = await reel.find({ project_id: project_id, reel_is_traverse: '1', reel_updated_at: { $lte: end_date, $gte: start_date } }).sort({ reel_updated_at: -1 });
                // console.log(reeldata);
                res.status(201).json(reeldata);
            }
            else if (start_date) {
                const reeldata = await reel.find({ project_id: project_id, reel_is_traverse: '1', reel_updated_at: { '$regex': start_date } }).sort({ reel_updated_at: -1 });
                // console.log(reeldata)
                res.status(201).json(reeldata);
            }
            else {
                res.status(422).json(error);
            }
            // console.log(reeldata);
        }
    }
    catch (error) {
        res.status(422).json(error);

    }
});


//get reeldata for table 
router.post("/getReelDataforTable", async (req, res) => {
    const { project_id, start_date, end_date } = req.body;
    // console.log("project_id: "+project_id)
    // console.log("start_date: "+start_date)
    // console.log("end_date: "+end_date)

    try {
        if (!project_id) {
            res.status(404).json("please fill the data");
        }
        else {

            if (end_date && start_date) {
                // const reeldata = await reel.find({ project_id: project_id, reel_is_traverse: '1', reel_updated_at: { $lte: end_date, $gte: start_date } }).sort({ reel_play: -1 }).collation({ locale: "en_US", numericOrdering: true }).limit(5);

                const reeldata = await reel.aggregate(
                    [
                        { $match: { project_id: project_id, reel_is_traverse: '1', reel_updated_at: { $lte: end_date, $gte: start_date } } },
                        { $group: { _id: "$reel_link", doc: { $last: "$$ROOT" }, count: { $sum: 1 } } },
                        { $sort: { "doc.reel_play": -1 } },
                        { "$limit": 5 }
                    ],
                    { collation: { locale: "en_US", numericOrdering: true } }
                )


                // console.log(reeldata);
                res.status(201).json(reeldata);
            }
            else if (start_date) {
                // const reeldata = await reel.find({ project_id: project_id, reel_is_traverse: '1', reel_updated_at: { '$regex': start_date } }).sort({ reel_play: -1 }).collation({ locale: "en_US", numericOrdering: true }).limit(5);

                const reeldata = await reel.aggregate(
                    [
                        { $match: { project_id: project_id, reel_is_traverse: '1', reel_updated_at: { '$regex': start_date } } },
                        { $group: { _id: "$reel_link", doc: { $last: "$$ROOT" }, count: { $sum: 1 } } },
                        { $sort: { "doc.reel_play": -1 } },
                        { "$limit": 5 }
                    ],
                    { collation: { locale: "en_US", numericOrdering: true } }
                )


                // console.log(reeldata)
                res.status(201).json(reeldata);
            }
            else if (project_id) {
                // const reeldata = await reel.find({ project_id: project_id, reel_is_traverse: '1' }).sort({ reel_play: -1 }).collation({ locale: "en_US", numericOrdering: true }).limit(5);
                // // console.log(reeldata)

                const reeldata = await reel.aggregate(
                    [
                        { $match: { project_id: project_id, reel_is_traverse: '1' } },
                        //   { $sort: { reel_play : -1 } },
                        { $group: { _id: "$reel_link", doc: { $last: "$$ROOT" }, count: { $sum: 1 } } },
                        { $sort: { "doc.reel_play": -1 } },
                        //   { $sort: { reel_play : -1 } },
                        { "$limit": 5 }
                    ],
                    { collation: { locale: "en_US", numericOrdering: true } }
                )



                // console.log(reeldata)

                res.status(201).json(reeldata);
            }
            else {
                res.status(422).json(error);
            }
            // console.log(reeldata);
        }
    }
    catch (error) {
        res.status(422).json(error);

    }
});

//get reeldata for graph
router.post("/getReelDetailsforGrpah", async (req, res) => {

    const { project_id, start_date, end_date } = req.body;

    // console.log(project_id)
    // console.log(start_date)
    // console.log(end_date)


    try {
        if (!project_id) {
            res.status(404).json("please fill the data");
        }
        else {

            if (end_date && start_date) {
                const reeldata = await reel.aggregate([
                    {
                        $addFields: {
                            reel_updated_at: {
                                $arrayElemAt: [{ $split: ["$reel_updated_at", " "] }, 0]
                            }
                        }
                    },
                    { $match: { project_id: project_id, reel_is_traverse: '1', reel_updated_at: { $lte: end_date, $gte: start_date } } },
                    {
                        $group: {
                            _id: "$reel_updated_at",
                            data: { $addToSet: { reelview: '$reel_play', reellike: '$reel_like', reelcomment: "$reel_comment" } },
                            links: { $sum: 1 },
                        }
                    },
                    {
                        $sort: { reel_updated_at: -1 }
                    }
                ])

                res.status(201).json(reeldata);
            }
            else if (start_date) {
                const reeldata = await reel.aggregate([
                    {
                        $addFields: {
                            reel_updated_at: {
                                $arrayElemAt: [{ $split: ["$reel_updated_at", " "] }, 0]
                            }
                        }
                    },
                    { $match: { project_id: project_id, reel_is_traverse: '1', reel_updated_at: { '$regex': start_date } } },
                    {
                        $group: {
                            _id: "$reel_updated_at",
                            data: { $addToSet: { reelview: '$reel_play', reellike: '$reel_like', reelcomment: "$reel_comment" } },
                            links: { $sum: 1 },
                        }
                    },
                    {
                        $sort: { reel_updated_at: -1 }
                    }
                ])

                res.status(201).json(reeldata);
            }
            else if (project_id) {

                const reeldata = await reel.aggregate([
                    { $match: { project_id: project_id, reel_is_traverse: '1' } },
                    {
                        $addFields: {
                            reel_updated_at: {
                                $arrayElemAt: [{ $split: ["$reel_updated_at", " "] }, 0]
                            }
                        }
                    },
                    {
                        $group: {
                            _id: "$reel_updated_at",
                            data: { $addToSet: { reelview: '$reel_play', reellike: '$reel_like', reelcomment: "$reel_comment" } },
                            links: { $sum: 1 },
                        }
                    },
                    {
                        $sort: { reel_updated_at: -1 }
                    }
                ])

                // console.log(reeldata)

                res.status(201).json(reeldata);
            }
            else {
                res.status(422).json(error);
            }
        }
    }
    catch (error) {
        res.status(422).json(error);

    }
});

//get upload link for graph
router.post("/getuploadLinkDataforGrpah", async (req, res) => {

    const { project_id, start_date, end_date } = req.body;

    // console.log(project_id)
    // console.log(start_date)
    // console.log(end_date)


    try {
        if (!project_id) {
            res.status(404).json("please fill the data");
        }
        else {

            if (end_date && start_date) {
                const reeldata = await reel.aggregate([
                    {
                        $addFields: {
                            reel_created_at: {
                                $arrayElemAt: [{ $split: ["$reel_created_at", " "] }, 0]
                            }
                        }
                    },
                    { $match: { project_id: project_id, reel_upload: '1', reel_created_at: { $lte: end_date, $gte: start_date } } },
                    {
                        $group: {
                            _id: "$reel_created_at",
                            links: { $sum: 1 },
                        }
                    },
                    {
                        $sort: { reel_created_at: -1 }
                    }
                ])

                res.status(201).json(reeldata);
            }
            else if (start_date) {
                const reeldata = await reel.aggregate([
                    {
                        $addFields: {
                            reel_created_at: {
                                $arrayElemAt: [{ $split: ["$reel_created_at", " "] }, 0]
                            }
                        }
                    },
                    { $match: { project_id: project_id, reel_upload: '1', reel_created_at: { '$regex': start_date } } },
                    {
                        $group: {
                            _id: "$reel_created_at",
                            links: { $sum: 1 },
                        }
                    },
                    {
                        $sort: { reel_created_at: -1 }
                    }
                ])

                res.status(201).json(reeldata);
            }
            else if (project_id) {

                const reeldata = await reel.aggregate([
                    { $match: { project_id: project_id, reel_upload: '1' } },
                    {
                        $addFields: {
                            reel_created_at: {
                                $arrayElemAt: [{ $split: ["$reel_created_at", " "] }, 0]
                            }
                        }
                    },
                    {
                        $group: {
                            _id: "$reel_created_at",
                            links: { $sum: 1 },
                        }
                    },
                    {
                        $sort: { reel_created_at: -1 }
                    }
                ])

                // console.log(reeldata)

                res.status(201).json(reeldata);
            }
            else {
                res.status(422).json(error);
            }
        }
    }
    catch (error) {
        res.status(422).json(error);

    }
});



// add Reel link
router.post("/addReelLink", async (req, res) => {

    const reeldatacount = (await reel.findOne().sort({ _id: -1 }).limit(1));

    const reel_id = (reeldatacount != null) ? parseInt(reeldatacount["reel_id"]) + 1 : "1";  //reel id auto imcrement

    const { reel_link, project_id, reel_is_traverse, reel_upload, reel_created_at, cronfunction } = req.body;   // getting data from user

    if (!reel_link || !project_id || !reel_created_at) {
        res.status(404).json("please fill the data");
    }
    else {
        try {

            var prereel = 0;

            if (!cronfunction) {
                var reel_link_info = reel_link.split("/");

                prereel = await reel.findOne({ reel_link: { '$regex': reel_link_info[4] }, project_id: project_id });
                // console.log(prereel);
            }

            if (prereel) {
                res.status(401).json("This reel link is already present");
            }
            else {

                const addReel = new reel({
                    reel_id, reel_link, project_id, reel_is_traverse, reel_upload, reel_created_at
                });

                await addReel.save();
                res.status(201).json(addReel);
                // console.log(addReel);
            }
        }
        catch (error) {
            res.status(404).json(error)
        }
    }

});


// add page links
router.post("/addPageLink", async (req, res) => {

    const pagedatacount = (await page.findOne().sort({ _id: -1 }).limit(1));

    const page_id = (pagedatacount != null) ? parseInt(pagedatacount["page_id"]) + 1 : "1";  //page id auto imcrement

    const { page_link, user_id, page_created_at, record_numbers, fileName, isfile, filerefrencedata } = req.body;   // getting data from user

    if (!page_link || !user_id || !page_created_at) {
        res.status(404).json("please fill the data");
    }
    else {
        try {

            var page_link_info = page_link.split("/")[3]
            if (page_link_info)
                page_link_info = page_link_info.split('?');
            if (page_link_info) {
                //create a batch id and a enter some details according to batch id 
                var batch_id = "0";
                if (isfile) {
                    const batchdata = await pagebatch.findOne({ batch_file_data: filerefrencedata });
                    if (!batchdata) {
                        var batch_total_links = record_numbers;
                        const batchdatacount = (await pagebatch.findOne().sort({ _id: -1 }).limit(1));
                        batch_id = (batchdatacount != null) ? parseInt(batchdatacount["batch_id"]) + 1 : "1";  //batch id auto increment
                        const batch_created_at = page_created_at;
                        const batch_name = fileName;
                        const batch_file_data = filerefrencedata
                        const batch_user_id = user_id;
                        const batch_is_traverse = "0";

                        const addBatch = new pagebatch({
                            batch_id, batch_user_id, batch_name, batch_file_data, batch_total_links, batch_is_traverse, batch_created_at
                        });

                        await addBatch.save();
                        batch_id = addBatch.batch_id
                    }
                    else {
                        batch_id = batchdata.batch_id
                    }
                }
                else {
                    const batchdatacount = (await pagebatch.findOne().sort({ _id: -1 }).limit(1));
                    batch_id = (batchdatacount != null) ? parseInt(batchdatacount["batch_id"]) + 1 : "1";  //batch id auto increment
                    const batch_created_at = page_created_at;
                    const batch_name = "Single Link At " + batch_created_at;
                    const batch_user_id = user_id;
                    const batch_is_traverse = "0";


                    const addBatch = new pagebatch({
                        batch_id, batch_user_id, batch_name, batch_is_traverse, batch_created_at
                    });

                    await addBatch.save();
                    batch_id = addBatch.batch_id
                }

                if (batch_id) {
                    var page_is_traverse = "0";

                    var prepage = await page.findOne({ page_link: { '$regex': page_link_info[0] }, batch_id: batch_id });

                    if (prepage) {
                        res.status(401).json("Page link is already present in this File");
                    }
                    else {

                        const addPage = new page({
                            page_id, page_link, user_id, page_is_traverse, batch_id, page_created_at
                        });

                        await addPage.save();
                        res.status(201).json(addPage);
                        // console.log(addPage);
                    }
                }
                else {
                    res.status(401).json("Some Error occur in batch id");
                }
            }
            else {
                res.status(404).json("Link is not valid"); 
            }

        }
        catch (error) {
            res.status(404).json(error)
        }
    }

});


//get batch data
router.post("/getBatchData", async (req, res) => {
    const { value, user_id } = req.body;
    try {

        if (user_id) {
            if (value) {
                const batchdata = await pagebatch.find({ batch_user_id: user_id, batch_name: { $regex: value, $options: "i" } });
                if (batchdata.length > 0) {
                    res.status(201).json(batchdata);
                }
                else {
                    const pagedata = await page.find({ user_id: user_id, page_link: { $regex: value, $options: "i" } } , { batch_id : 1, _id: 0 } );
                    if (pagedata.length > 0) { 
                        let pagebatchid = pagedata.map(element => element.batch_id);
                        const batchdata = await pagebatch.find({ batch_id: pagebatchid });
                        // console.log(batchdata);
                        res.status(201).json(batchdata);  
                    }
                    else {
                        const batchdata = await pagebatch.find({ batch_user_id: user_id });
                        // console.log(batchdata);
                        res.status(201).json(batchdata);  
                    }
                }
            }
            else {
                const batchdata = await pagebatch.find({ batch_user_id: user_id });
                // console.log(batchdata);
                res.status(201).json(batchdata);
            }
        }
        else {
            if (value) {
                const batchdata = await pagebatch.find({ batch_name: { $regex: value, $options: "i" } });
                if (batchdata.length > 0) {
                    res.status(201).json(batchdata);
                }
                else {
                    const pagedata = await page.find({ page_link: { $regex: value, $options: "i" } } , { batch_id : 1, _id: 0 } );
                    if (pagedata.length > 0) { 
                        let pagebatchid = pagedata.map(element => element.batch_id);
                        const batchdata = await pagebatch.find({ batch_id: pagebatchid });
                        // console.log(batchdata);
                        res.status(201).json(batchdata);  
                    }
                    else {
                        const batchdata = await pagebatch.find({});
                        // console.log(batchdata);
                        res.status(201).json(batchdata);  
                    }
                }
            }
            else {
                const batchdata = await pagebatch.find({});
                // console.log(batchdata);
                res.status(201).json(batchdata);
            }
        }
        
    }
    catch (error) {
        res.status(422).json(error);

    }

});

//get Traverse cron data  
router.get("/getTraverseCronData", async (req, res) => {

    // to get date today
    let today = new Date();

    let date = today.toLocaleString('en-GB').split('/');
    let time = today.toLocaleString('en-GB').split('/')[2].split(',');
    let date_needed = time[0] + "-" + date[1] + "-" + date[0];

    // console.log(date_needed);


    try {

        if (date_needed) {
            const crondata = await cron.findOne({ cron_traverse_status: '2', cron_created_at: date_needed });
            if (!crondata) {
                const cron_total_links = await reel.find({ reel_is_traverse: '2', reel_updated_at: { '$regex': date_needed } }).count();
                if (cron_total_links) {
                    var cron_limit_set = Math.round(parseInt(cron_total_links) / 2);
                    const crondatacount = (await cron.findOne().sort({ _id: -1 }).limit(1));
                    const cron_id = (crondatacount != null) ? parseInt(crondatacount["cron_id"]) + 1 : "1";  //cron id auto imcrement
                    const cron_created_at = date_needed;
                    const cron_traverse_status = 2;

                    const addCron = new cron({
                        cron_id, cron_total_links, cron_limit_set, cron_traverse_status, cron_created_at
                    });

                    await addCron.save();
                    res.status(201).json(addCron);
                }
                else {
                    res.status(422).json(error);
                }

            }
            else {
                res.status(201).json(crondata);
            }

        }
        else {
            res.status(422).json(error);
        }
    }
    catch (error) {
        res.status(422).json(error);

    }
});

//get Non Traverse cron data  
router.get("/getCronData", async (req, res) => {

    // to get date today
    let today = new Date();

    let date = today.toLocaleString('en-GB').split('/');
    let time = today.toLocaleString('en-GB').split('/')[2].split(',');
    let date_needed = time[0] + "-" + date[1] + "-" + date[0];

    // console.log(date_needed);

    let require_date = new Date(today);
    require_date.setDate(today.getDate() - 1);
    let y_date = require_date.toLocaleString('en-GB').split('/');
    let y_time = require_date.toLocaleString('en-GB').split('/')[2].split(',');
    let yesterday_date = y_time[0] + "-" + y_date[1] + "-" + y_date[0];



    try {

        if (date_needed) {
            const crondata = await cron.findOne({ cron_traverse_status: '0', cron_created_at: date_needed });
            if (!crondata) {
                const cron_total_links = await reel.find({ reel_created_at: { '$regex': yesterday_date } }).count();
                if (cron_total_links) {
                    var cron_limit_set = Math.round(parseInt(cron_total_links) / 4);
                    const crondatacount = (await cron.findOne().sort({ _id: -1 }).limit(1));
                    const cron_id = (crondatacount != null) ? parseInt(crondatacount["cron_id"]) + 1 : "1";  //cron id auto imcrement
                    const cron_created_at = date_needed;
                    const cron_traverse_status = 0;

                    const addCron = new cron({
                        cron_id, cron_total_links, cron_limit_set, cron_traverse_status, cron_created_at
                    });

                    await addCron.save();
                    res.status(201).json(addCron);
                }
                else {
                    res.status(422).json(error);
                }

            }
            else {
                res.status(201).json(crondata);
            }

        }
        else {
            res.status(422).json(error);
        }
    }
    catch (error) {
        res.status(422).json(error);

    }
});



//get Non Traverse reeldata for cron 
router.get("/getReelData/:limit", async (req, res) => {

    // to get date one day previous
    let today = new Date();
    let require_date = new Date(today);
    require_date.setDate(today.getDate() - 1);
    let date = require_date.toLocaleString('en-GB').split('/');
    let time = require_date.toLocaleString('en-GB').split('/')[2].split(',');
    let date_needed = time[0] + "-" + date[1] + "-" + date[0];

    // // console.log(date_needed);

    const { limit } = req.params;

    // // to get date today
    // let today = new Date();

    // let date = today.toLocaleString('en-GB').split('/');
    // let time = today.toLocaleString('en-GB').split('/')[2].split(',');
    // let date_needed = time[0] + "-" + date[1] + "-" + date[0];

    // console.log(date_needed);


    try {

        if (date_needed) {
            const reeldata = await reel.find({ reel_is_traverse: '0', reel_created_at: { '$regex': date_needed } }, { reel_link: 1, _id: 1, project_id: 1 }).sort({ reel_id: 1 }).collation({ locale: "en_US", numericOrdering: true }).limit(limit);
            // console.log(reeldata.length);

            res.status(201).json(reeldata);
        }
        else {
            res.status(422).json(error);
        }
    }
    catch (error) {
        res.status(422).json(error);

    }
});

//get Traverse reeldata for cron 
router.get("/getTraverseReelData/:limit", async (req, res) => {

    // // to get date one day previous
    // let today = new Date();
    // let require_date = new Date(today);
    // require_date.setDate(today.getDate() - 1);
    // let date = require_date.toLocaleString('en-GB').split('/');
    // let time = require_date.toLocaleString('en-GB').split('/')[2].split(',');
    // let date_needed = time[0] + "-" + date[1] + "-" + date[0];

    // // console.log(date_needed);

    const { limit } = req.params;

    // to get date today
    let today = new Date();

    let date = today.toLocaleString('en-GB').split('/');
    let time = today.toLocaleString('en-GB').split('/')[2].split(',');
    let date_needed = time[0] + "-" + date[1] + "-" + date[0];

    // console.log(date_needed);


    try {

        if (date_needed) {
            const reeldata = await reel.find({ reel_is_traverse: '2', reel_updated_at: { '$regex': date_needed } }, { reel_link: 1, _id: 1, project_id: 1 }).sort({ reel_id: 1 }).collation({ locale: "en_US", numericOrdering: true }).limit(limit);
            // console.log(reeldata.length);

            res.status(201).json(reeldata);
        }
        else {
            res.status(422).json(error);
        }
    }
    catch (error) {
        res.status(422).json(error);

    }
});


//get Retry Traverse reeldata for cron 
router.get("/retryTraverseReelData", async (req, res) => {

    const { limit } = req.params;

    // to get date today
    let today = new Date();

    let date = today.toLocaleString('en-GB').split('/');
    let time = today.toLocaleString('en-GB').split('/')[2].split(',');
    let date_needed = time[0] + "-" + date[1] + "-" + date[0];

    // console.log(date_needed);


    try {

        if (date_needed) {
            const reeldata = await reel.find({ reel_is_traverse: '3', reel_updated_at: { '$regex': date_needed } }, { reel_link: 1, _id: 1, project_id: 1 }).sort({ reel_id: 1 }).collation({ locale: "en_US", numericOrdering: true });
            // console.log(reeldata.length);

            res.status(201).json(reeldata);
        }
        else {
            res.status(422).json(error);
        }
    }
    catch (error) {
        res.status(422).json(error);

    }
});


//update category
router.patch("/updateReelData/:id", async (req, res) => {
    try {
        // console.log(req.params);
        const { id } = req.params;
        // console.log(id);


        const reel_update = await reel.findByIdAndUpdate(id, req.body, {
            new: true
        });

        // console.log(reel_update);
        res.status(201).json(reel_update)
    }
    catch (error) {
        res.status(422).json(error);
    }

});



function datetime(type, days) {
    if (type === 'currentdate') {
        let today = new Date();
        let date = today.toLocaleString('en-GB').split('/');
        let time = today.toLocaleString('en-GB').split('/')[2].split(',');
        date = time[0] + "-" + date[1] + "-" + date[0];
        return date;
    }
    if (type === 'currentdatetime') {
        let today = new Date();
        let date = today.toLocaleString('en-GB').split('/');
        let time = today.toLocaleString('en-GB').split('/')[2].split(',');
        date = time[0] + "-" + date[1] + "-" + date[0];
        time = time[1];
        return date + " " + time;
    }
    if (type === 'yesterdaydate') {
        let today = new Date();
        let require_date = new Date(today);
        require_date.setDate(today.getDate() - 1);
        let date = require_date.toLocaleString('en-GB').split('/');
        let time = require_date.toLocaleString('en-GB').split('/')[2].split(',');
        let yesterdaydate = time[0] + "-" + date[1] + "-" + date[0];
        return yesterdaydate;
    }
    if (type === 'customdate') {

        let today = new Date();
        let requiredate = new Date(today);
        requiredate.setDate(today.getDate() - days);
        let date = requiredate.toLocaleString('en-GB').split('/');
        let time = requiredate.toLocaleString('en-GB').split('/')[2].split(',');
        let require_date = time[0] + "-" + date[1] + "-" + date[0];

        return require_date;
    }


}




// testingcron
router.get("/testingcron", async (req, res) => {
    try {

        var options = {
            "method": "GET",
            "hostname": "instagram-profile1.p.rapidapi.com",
            "port": null,
            "path": `/getpost/Ce8j3vhB_NZ`,
            "headers": {
                "X-RapidAPI-Key": '29e3a657f0mshd2cf724a6f23862p1cbc59jsn1f05b4efdb57',
                "X-RapidAPI-Host": "instagram-profile1.p.rapidapi.com",
                "useQueryString": true
            }
        };

        var req = http.request(options, function (res) {
            var chunks = [];

            res.on("data", function (chunk) {
                chunks.push(chunk);
            });

            res.on("end", async function () {
                const body = Buffer.concat(chunks);
                // console.log(JSON.parse(body.toString()));

                var data = JSON.parse(body.toString());

                if (data.owner) {
                    let reel_page_name = data.owner['username']
                    let reel_view = (data.media['video_views'] ? data.media['video_views'] : null)
                    let reel_play = (data.media['video_play'] ? data.media['video_play'] : null)
                    let reel_like = data.media['like']
                    let reel_comment = data.media['comment_count']
                    let reel_caption = data.media['caption']
                    let reel_date_of_posting = data.media['timestamp']

                    // console.log("reel_page_name: " + reel_page_name)
                    // console.log("reel_play: " + reel_play)
                    // console.log("reel_view: " + reel_view)
                    // console.log("reel_like: " + reel_like)
                    // console.log("reel_comment: " + reel_comment)
                    // console.log("reel_caption: " + reel_caption)
                    // console.log("reel_date_of_posting: " + reel_date_of_posting)
                }


            });
        });

        req.end();
    }
    catch (error) {
        res.status(422).json(error);

    }
});


//get cron Reel Api
router.get("/cronReelApi", async (request, response) => {

    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

    try {

        let todaydate = datetime('currentdate');

        let yesterday_date = datetime('yesterdaydate')
        var crondata = {};
        if (todaydate) {
            crondata = await cron.findOne({ cron_traverse_status: '0', cron_created_at: todaydate });
            if (!crondata) {
                const cron_total_links = await reel.find({ reel_created_at: { '$regex': yesterday_date } }).count();
                if (cron_total_links) {
                    var cron_limit_set = Math.round(parseInt(cron_total_links) / 4);
                    const crondatacount = (await cron.findOne().sort({ _id: -1 }).limit(1));
                    const cron_id = (crondatacount != null) ? parseInt(crondatacount["cron_id"]) + 1 : "1";  //cron id auto imcrement
                    const cron_created_at = todaydate;
                    const cron_traverse_status = 0;

                    const addCron = new cron({
                        cron_id, cron_total_links, cron_limit_set, cron_traverse_status, cron_created_at
                    });

                    await addCron.save();
                    crondata = addCron
                }
                else {
                    response.status(422).json(error)
                }
            }
        }

        // to get date one day previous
        let date_needed = datetime('yesterdaydate')

        if (date_needed && crondata) {
            var cron_limit_set = crondata.cron_limit_set;

            const reeldata = await reel.find({ reel_is_traverse: '0', reel_created_at: { '$regex': date_needed } }, { reel_link: 1, _id: 1, project_id: 1 }).sort({ reel_id: 1 }).collation({ locale: "en_US", numericOrdering: true }).limit(cron_limit_set);
            console.log(reeldata.length);

            var apikey = ['29e3a657f0mshd2cf724a6f23862p1cbc59jsn1f05b4efdb57', '98313acb74mshb662220473bc42bp11c728jsn1d8abc671b3b', 'c6cf21ca34msh526fcb983fa64bap1cb2dajsnb3f1993739d4']

            for (let index = 0; index < reeldata.length; index++) {

                let api_key = apikey[index % 3]

                let reellink = reeldata[index];

                if (reellink.reel_link.split("/")[4]) {

                    let reel_shortcode = reellink.reel_link.split("/")[4]

                    var currentdatetime = datetime('currentdatetime')

                    let reel_link = reellink.reel_link;
                    let project_id = reellink.project_id;
                    let reel_is_traverse = "0";
                    let reel_created_at = currentdatetime;

                    // db.coll_reels_2.find().sort({_id:-1}).limit(1)

                    var reeldatacount = await reel.find().sort({ _id: -1 }).limit(1);
                    let reel_id = (reeldatacount != null) ? parseInt(reeldatacount[0]["reel_id"]) + 1 : "1";  //reel id auto imcrement


                    if (reel_link && project_id && reel_created_at) {
                        let addReel = new reel({
                            reel_id, reel_link, project_id, reel_is_traverse, reel_created_at
                        });
                        await addReel.save();
                    }

                    var options = {
                        "method": "GET",
                        "hostname": "instagram-profile1.p.rapidapi.com",
                        "port": null,
                        "path": `/getpost/${reel_shortcode}`,
                        "headers": {
                            "X-RapidAPI-Key": api_key,
                            "X-RapidAPI-Host": "instagram-profile1.p.rapidapi.com",
                            "useQueryString": true
                        }
                    };

                    var req = http.request(options, function (res) {
                        var chunks = [];

                        res.on("data", function (chunk) {
                            chunks.push(chunk);
                        });

                        res.on("end", async function () {
                            const body = Buffer.concat(chunks);
                            // console.log(JSON.parse(body.toString()));

                            var data = JSON.parse(body.toString());

                            if (data.message) {
                                let reel_error = data.message
                                let reel_is_traverse = "2"
                                let reel_updated_at = currentdatetime

                                var id = reellink._id;

                                // console.log(id)
                                await reel.findByIdAndUpdate(id, { $set: { reel_error: reel_error, reel_is_traverse: reel_is_traverse, reel_updated_at: reel_updated_at } }, {
                                    new: true
                                });
                            }
                            else if (data.owner) {
                                let reel_page_name = data.owner['username']
                                let reel_view = (data.media['video_views'] ? data.media['video_views'] : null)
                                let reel_play = (data.media['video_play'] ? data.media['video_play'] : null)
                                let reel_like = data.media['like']
                                let reel_comment = data.media['comment_count']
                                let reel_caption = data.media['caption']
                                let reel_date_of_posting = data.media['timestamp']
                                let reel_is_traverse = "1"

                                let reel_updated_at = currentdatetime

                                var id = reellink._id;
                                // console.log(id)
                                await reel.findByIdAndUpdate(id, { $set: { reel_page_name: reel_page_name, reel_view: reel_view, reel_play: reel_play, reel_like: reel_like, reel_comment: reel_comment, reel_caption: reel_caption, reel_date_of_posting: reel_date_of_posting, reel_is_traverse: reel_is_traverse, reel_updated_at: reel_updated_at } }, {
                                    new: true
                                });

                            }


                        });
                    });

                    req.end();
                    await sleep(1500);

                }

                else {
                    let reel_error = "link is not correct"
                    let reel_is_traverse = "-1"

                    var currentdatetime = datetime('currentdatetime')

                    let reel_updated_at = currentdatetime

                    var id = reellink._id;

                    // console.log(id)
                    await reel.findByIdAndUpdate(id, { $set: { reel_error: reel_error, reel_is_traverse: reel_is_traverse, reel_updated_at: reel_updated_at } }, {
                        new: true
                    });
                }

            }

            console.log("complete");
            response.status(201).json("cronReelApi hit successfull");

        }
        else {
            response.status(422).json(error)
        }
    }
    catch (error) {
        response.status(422).json(error)
    }
});


//get cron Reel Traverse 
router.get("/cronReelTraverse", async (request, response) => {

    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

    try {

        let todaydate = datetime('currentdate');

        var crondata = {};
        if (todaydate) {
            crondata = await cron.findOne({ cron_traverse_status: '2', cron_created_at: todaydate });
            if (!crondata) {
                const cron_total_links = await reel.find({ reel_is_traverse: '2', reel_updated_at: { '$regex': todaydate } }).count();
                if (cron_total_links) {
                    var cron_limit_set = Math.round(parseInt(cron_total_links) / 2);
                    const crondatacount = (await cron.findOne().sort({ _id: -1 }).limit(1));
                    const cron_id = (crondatacount != null) ? parseInt(crondatacount["cron_id"]) + 1 : "1";  //cron id auto imcrement
                    const cron_created_at = todaydate;
                    const cron_traverse_status = 2;

                    const addCron = new cron({
                        cron_id, cron_total_links, cron_limit_set, cron_traverse_status, cron_created_at
                    });

                    await addCron.save();
                    crondata = addCron
                }
                else {
                    response.status(422).json(error)
                }
            }
        }


        // to get date one day previous
        let date_needed = todaydate;

        if (date_needed && crondata) {
            var cron_limit_set = crondata.cron_limit_set;

            const reeldata = await reel.find({ reel_is_traverse: '2', reel_updated_at: { '$regex': date_needed } }, { reel_link: 1, _id: 1, project_id: 1 }).sort({ reel_id: 1 }).collation({ locale: "en_US", numericOrdering: true }).limit(cron_limit_set);
            console.log(reeldata.length);

            var apikey = ['29e3a657f0mshd2cf724a6f23862p1cbc59jsn1f05b4efdb57', '98313acb74mshb662220473bc42bp11c728jsn1d8abc671b3b', 'c6cf21ca34msh526fcb983fa64bap1cb2dajsnb3f1993739d4']

            for (let index = 0; index < reeldata.length; index++) {

                let api_key = apikey[index % 3]

                let reellink = reeldata[index];

                if (reellink.reel_link.split("/")[4]) {

                    let reel_shortcode = reellink.reel_link.split("/")[4]

                    var currentdatetime = datetime('currentdatetime')

                    var options = {
                        "method": "GET",
                        "hostname": "instagram-profile1.p.rapidapi.com",
                        "port": null,
                        "path": `/getpost/${reel_shortcode}`,
                        "headers": {
                            "X-RapidAPI-Key": api_key,
                            "X-RapidAPI-Host": "instagram-profile1.p.rapidapi.com",
                            "useQueryString": true
                        }

                    };

                    var req = http.request(options, function (res) {
                        var chunks = [];

                        res.on("data", function (chunk) {
                            chunks.push(chunk);
                        });

                        res.on("end", async function () {
                            const body = Buffer.concat(chunks);
                            // console.log(JSON.parse(body.toString()));

                            var data = JSON.parse(body.toString());

                            if (data.message) {
                                let reel_error = data.message
                                let reel_is_traverse = "3"
                                let reel_updated_at = currentdatetime

                                var id = reellink._id;

                                // console.log(id)
                                await reel.findByIdAndUpdate(id, { $set: { reel_error: reel_error, reel_is_traverse: reel_is_traverse, reel_updated_at: reel_updated_at } }, {
                                    new: true
                                });
                            }
                            else if (data.owner) {
                                let reel_page_name = data.owner['username']
                                let reel_view = (data.media['video_views'] ? data.media['video_views'] : null)
                                let reel_play = (data.media['video_play'] ? data.media['video_play'] : null)
                                let reel_like = data.media['like']
                                let reel_comment = data.media['comment_count']
                                let reel_caption = data.media['caption']
                                let reel_date_of_posting = data.media['timestamp']
                                let reel_is_traverse = "1"

                                let reel_updated_at = currentdatetime

                                var id = reellink._id;
                                // console.log(id)
                                await reel.findByIdAndUpdate(id, { $set: { reel_page_name: reel_page_name, reel_view: reel_view, reel_play: reel_play, reel_like: reel_like, reel_comment: reel_comment, reel_caption: reel_caption, reel_date_of_posting: reel_date_of_posting, reel_is_traverse: reel_is_traverse, reel_updated_at: reel_updated_at } }, {
                                    new: true
                                });

                            }


                        });
                    });

                    req.end();
                    await sleep(1000);

                }

                else {
                    let reel_error = "link is not correct"
                    let reel_is_traverse = "-1"

                    var currentdatetime = datetime('currentdatetime')

                    let reel_updated_at = currentdatetime

                    var id = reellink._id;

                    // console.log(id)
                    await reel.findByIdAndUpdate(id, { $set: { reel_error: reel_error, reel_is_traverse: reel_is_traverse, reel_updated_at: reel_updated_at } }, {
                        new: true
                    });
                }

            }

            console.log("complete");
            response.status(201).json("cronReelTraverse hit successfull");

        }
        else {
            response.status(422).json(error)
        }
    }
    catch (error) {
        response.status(422).json(error)
    }
});





//get cron Reel Retry
router.get("/cronReelRetry", async (request, response) => {

    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

    try {

        let date_needed = datetime('currentdate');

        if (date_needed) {

            const reeldata = await reel.find({ reel_is_traverse: '3', reel_updated_at: { '$regex': date_needed } }, { reel_link: 1, _id: 1, project_id: 1 }).sort({ reel_id: 1 }).collation({ locale: "en_US", numericOrdering: true });
            console.log(reeldata.length);

            var apikey = ['29e3a657f0mshd2cf724a6f23862p1cbc59jsn1f05b4efdb57', '98313acb74mshb662220473bc42bp11c728jsn1d8abc671b3b', 'c6cf21ca34msh526fcb983fa64bap1cb2dajsnb3f1993739d4']

            for (let index = 0; index < reeldata.length; index++) {

                let api_key = apikey[index % 3]

                let reellink = reeldata[index];

                if (reellink.reel_link.split("/")[4]) {

                    let reel_shortcode = reellink.reel_link.split("/")[4]

                    var currentdatetime = datetime('currentdatetime')

                    var options = {
                        "method": "GET",
                        "hostname": "instagram-profile1.p.rapidapi.com",
                        "port": null,
                        "path": `/getpost/${reel_shortcode}`,
                        "headers": {
                            "X-RapidAPI-Key": api_key,
                            "X-RapidAPI-Host": "instagram-profile1.p.rapidapi.com",
                            "useQueryString": true
                        }
                    };

                    var req = http.request(options, function (res) {
                        var chunks = [];

                        res.on("data", function (chunk) {
                            chunks.push(chunk);
                        });

                        res.on("end", async function () {
                            const body = Buffer.concat(chunks);
                            // console.log(JSON.parse(body.toString()));

                            var data = JSON.parse(body.toString());

                            if (data.message) {
                                let reel_error = data.message
                                let reel_is_traverse = "3"
                                let reel_updated_at = currentdatetime

                                var id = reellink._id;

                                // console.log(id)
                                await reel.findByIdAndUpdate(id, { $set: { reel_error: reel_error, reel_is_traverse: reel_is_traverse, reel_updated_at: reel_updated_at } }, {
                                    new: true
                                });
                            }
                            else if (data.owner) {
                                let reel_page_name = data.owner['username']
                                let reel_view = (data.media['video_views'] ? data.media['video_views'] : null)
                                let reel_play = (data.media['video_play'] ? data.media['video_play'] : null)
                                let reel_like = data.media['like']
                                let reel_comment = data.media['comment_count']
                                let reel_caption = data.media['caption']
                                let reel_date_of_posting = data.media['timestamp']
                                let reel_is_traverse = "1"

                                let reel_updated_at = currentdatetime

                                var id = reellink._id;
                                // console.log(id)
                                await reel.findByIdAndUpdate(id, { $set: { reel_page_name: reel_page_name, reel_view: reel_view, reel_play: reel_play, reel_like: reel_like, reel_comment: reel_comment, reel_caption: reel_caption, reel_date_of_posting: reel_date_of_posting, reel_is_traverse: reel_is_traverse, reel_updated_at: reel_updated_at } }, {
                                    new: true
                                });

                            }


                        });
                    });

                    req.end();
                    await sleep(1500);

                }

                else {
                    let reel_error = "link is not correct"
                    let reel_is_traverse = "-1"

                    var currentdatetime = datetime('currentdatetime')

                    let reel_updated_at = currentdatetime

                    var id = reellink._id;

                    // console.log(id)
                    await reel.findByIdAndUpdate(id, { $set: { reel_error: reel_error, reel_is_traverse: reel_is_traverse, reel_updated_at: reel_updated_at } }, {
                        new: true
                    });
                }

            }

            console.log("complete");
            response.status(201).json("cronReelRetry hit successfull");

        }
        else {
            response.status(422).json(error)
        }
    }
    catch (error) {
        response.status(422).json(error)
    }
});


router.get("/SendEmail", async (request, response) => {

    try {
        var nodemailer = require("nodemailer");
        var sender = nodemailer.createTransport({
            service: "gmail",
            host: "smtp.gmail.com",
            auth: {
                user: "aryan.mehta524@gmail.com",
                pass: `mcddhbbstsguuisc`
            }
        });

        var mail = {
            from: "aryan.mehta524@gmail.com",
            to: "ikbirsingh97@gmail.com",
            subject: "Sending Email using Node.js",
            text: "That was easy!"
        };

        sender.sendMail(mail, function (error, info) {
            if (error) {
                console.log(error);
                response.status(422).json(error);

            } else {
                console.log("Email sent successfully: "
                    + info.response);
                response.status(201).json("Success");
            }

        });

    }
    catch (error) {
        response.status(422).json(error)
    }
});






module.exports = router;